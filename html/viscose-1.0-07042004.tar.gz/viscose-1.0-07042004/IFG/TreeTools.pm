#! /usr/bin/perl -w
###################################################################################################
# treeparse.pl
# (c) 2002 Michael Spitzer, IFG-IZKF

use strict;
use diagnostics;
package IFG::TreeTools;
require Exporter;

our @EXPORT  = qw(_read_phylip_tree _recurse_tree _parse_phylip_tree get_phylip_tree);

our $VERSION = "03.12.2002";

sub _read_phylip_tree {
   my $param            = $_[0];
   my @tree             = ();

   open(_phb_, "<".$param->{"phb"}) or die "[IOErr] Could not open '".$param->{"phb"}."'\n";
   (@tree = <_phb_>) =~ s/\n//g;
   close(_phb_);
   return (\@tree, scalar(@tree));
}

sub _recurse_tree {
   my $tree                   = $_[0];       # pointer to an array containing the treefile
   my $line                   = $_[1];       # indicates which line of the treefile we operate at
   my $current_node           = $_[2];       # pointer to the current_node
   my $depth                  = $_[3];       # the branch-depth we currently operate in
   my $len                    = $_[4];       # number of lines in treefile
   my $param                  = $_[5];
   my %new_node               = ();          # used to store contents for a new child-node if nessecary

   if ($line < $len) {
      CASE: {
         if ($tree->[$line] =~ m/\A\(/) {
            if ($param->{'debug'}) { print "[$depth] ".("  " x $depth)."*\n"; }                                           # add a childnode to the current node and continue...
            $new_node{"parent"} = $current_node;
            push(@{$current_node->{"children"}}, \%new_node);
            &_recurse_tree($tree, ++$line, \%new_node, ++$depth, $len, $param);                                           # ...the analysis with this new child.
            last CASE;
         }
         if ($tree->[$line] =~ m/(.+):([0-9\.\-]+),/) {
            if ($param->{'debug'}) { print "[$depth] ".("  " x $depth)."$1\n"; }
            push(@{$current_node->{"members"}},       $1);                                                                # add member/branchlength to the current node...
            push(@{$current_node->{"branchlengths"}}, $2);
            &_recurse_tree($tree, ++$line, $current_node, $depth, $len, $param);                                          # ...and continue analysis with the current node.
            last CASE;
         }
         if ($tree->[$line] =~ m/(.+):([0-9\.\-]+)\)/) {
            if ($param->{'debug'}) { print "[$depth] ".("  " x $depth)."$1, back to depth ".($depth-1)."\n"; }
            push(@{$current_node->{"members"}},       $1);                                                                # add member/branchlength to the current node...
            push(@{$current_node->{"branchlengths"}}, $2);
            &_recurse_tree($tree, ++$line, $current_node->{"parent"}, --$depth, $len, $param);                            # ...and continue analysis with the !parental! node.
            last CASE;
         }
         if ($tree->[$line] =~ m/\A:([0-9\.\-]+)\[?(\d*)\]?,/) {
            push(@{$current_node->{"branchlengths"}}, $1);
            if ($2) {
               if ($param->{'debug'}) { print "[$depth] ".("  " x $depth)."[$2]\n"; }                                     # add bootstrap/branchlength to the current node...
               push(@{$current_node->{"bootstrap"}}, $2);
            }
            else {
               if ($param->{'debug'}) { print "[$depth] ".("  " x $depth)."[0]\n"; }                                      # add bootstrap/branchlength to the current node...
               push(@{$current_node->{"bootstrap"}}, 0);
            }
            &_recurse_tree($tree, ++$line, $current_node, $depth, $len, $param);                                          # ...and continue analysis with the current node.
            last CASE;
         }
         if ($tree->[$line] =~ m/\A:([0-9\.\-]+)\[?(\d*)\]?\)/) {
            push(@{$current_node->{"branchlengths"}}, $1);
            if ($2) {
               if ($param->{'debug'}) { print "[$depth] ".("  " x $depth)."[$2], back to depth ".($depth-1)."\n"; }       # add bootstrap/branchlength to the current node...
               push(@{$current_node->{"bootstrap"}}, $2);
            }
            else {
               if ($param->{'debug'}) { print "[$depth] ".("  " x $depth)."[0], back to depth ".($depth-1)."\n"; }        # add bootstrap/branchlength to the current node...
               push(@{$current_node->{"bootstrap"}}, 0);
            }
            &_recurse_tree($tree, ++$line, $current_node->{"parent"}, --$depth, $len, $param);                            # ...and continue analysis with the !parental! node.
            last CASE;
         }
      }
   }
   return $current_node;
}

sub _parse_phylip_tree {
   my $tree                   = $_[0];
   my $len                    = $_[1];
   my $param                  = $_[2];
   my $line                   = 0;
   my %node                   = ();

   return &_recurse_tree($tree, $line, \%node, 1, $len, $param);;
}

sub get_phylip_tree {
   my $param                  = $_[0];
   
   my ($tree, $len) = &_read_phylip_tree($param);
   my $hashed_tree  = &_parse_phylip_tree($tree, $len, $param);
   return $hashed_tree;
}
